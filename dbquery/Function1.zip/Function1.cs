using System;
using System.Configuration;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;

namespace dbquery
{
    public static class Function1
    {
        [FunctionName("Function1")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log, ExecutionContext context)
        {
            //var config = new ConfigurationBuilder()
            //.SetBasePath(context.FunctionAppDirectory)
            //.AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
            //.AddEnvironmentVariables()
            //.Build();
            //var appSettingValue = config["localdb"];
            //var connection = config.GetConnectionString("localdb");


            var connstr = Environment.GetEnvironmentVariable("localdb");
            Console.WriteLine($"localdb connection string: {connstr}");
            //var envs = Environment.GetEnvironmentVariables();
            //foreach (var key in envs.Keys) {
            //    var value = envs[key];
            //    Console.WriteLine(value);
            //}

            log.LogInformation("C# HTTP trigger function processed a request.");

            string name = req.Query["name"];

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(requestBody);
            name = name ?? data?.name;

            string responseMessage = string.IsNullOrEmpty(name)
                ? "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response."
                : $"Hello, {name}. This HTTP triggered function executed successfully.";

            //var dbconn = new DbConn();
            //var cstr = DbConn.GetConnectionString();

            //var cstr = ConfigurationManager.ConnectionStrings["localdb"].ConnectionString;

            //var foo = new Foo();

            //var cstr = GetConnectionString();

            //var cstr = Environment.GetEnvironmentVariable("CUSTOMCONNSTR_localdb");

            return new OkObjectResult(responseMessage);
        }
    }

    public static class DbConn
    {
        public static string GetConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["localdb"].ConnectionString;
        }
    }

    public class Foo
    {
        public Foo()
        {
            Console.WriteLine("hi");
        }
    }
}
